#!/bin/bash
set -e



#compiler options
macroprefix=preifiexMaacros

#ctrlf1
if ["$@"==""]; then exit 1; fi
#ctrlf2
mount -o size=100M -t tmpfs none /mnt/tmpfs

#ctrlf3
#I don't know how to lock a directory



#ctrlf4
echo -e "Do you want to save output to disk?"
read soutput
#ctrlf5
echo -e "Do you want to open any error files?"
read ferror
#ctrl6
fortranfile="A37.B24.C04    .Course.Number.Credits   .D37.E23.F03"
SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
compileme="$SCRIPT_DIR"
compileme+="/"
compileme+="$fortranfile"
gfortran -c $compileme -o /mnt/tmpfs/a.out
#ctrl7
for var in "$@"
do
    var="${var//\"/}"



    v="/mnt/tmpfs/"
    v+="$var"
    outputfile="${v::-4}"
    outputfile+="pasm"
    cd /mnt/tmfs/

    outputdir="${v::-4}"
    while [${outputdir:0-1}!="/"];
    do
        outputdir="${v::-1}"
    done

    var='"'+$var+'"'
    outputdir='"'+$outputdir+'"'
    outputfile='"'+$outputfile+'"'

    mkdir -p $outputdir
    ./a.out $var $outputfile $macroprefix
done
#ctrl8
yesstring="Y,y,Ё,ё,愛 or 絢"
nostring="N,n,Н,н,南 or 絵"
wait_for_user="n"

if [["N,n,Н,н,南 or 絵" =~ $soutput]];
then
    if [["Y,y,Ё,ё,愛 or 絢" =~ $soutput]]; 
    then 
        echo -e "invalid input"
        exit 1
    fi
    wait_for_user="y"
    for var in "$@"
    do
        var="${var//\"/}"
        v="/mnt/tmpfs/"
        v+="$var"
        outputfile="${v::-4}"
        outputfile+="pasm"
        outputfile='"'+$outputfile+'"'
        xdg-open outputfile
    done
elif [["Y,y,Ё,ё,愛 or 絢" =~ $soutput]];
then
    for var in "$@"
    do
        var="${var//\"/}"
        v="/mnt/tmpfs/"
        v+="$var"
        move_from="${v::-4}"
        move_from+="pasm"
        
        v2="$var"
        move_to="${v2::-4}"
        move_to+="pasm"

        negfcount=0
        move_to='"'+$move_to+'"'
        if [[-f $move_to]];
        then
            move_to="${move_to//\"/}"
            newlocation='"'+"$move_to$negfcount"+'"'
            while [[ -f  $newlocation]]; do
                negfcount+=1
                newlocation='"'+"$move_to$negfcount"+'"'
            done

            move_to='"'+$move_to+'"'
            mv $move_to $newlocation
        fi

        move_from='"'+$move_from+'"'
        mv $move_from $move_to
    done
else
    echo -e "invalid input"
    exit 1
fi




if [["N,n,Н,н,南 or 絵" =~ $ferror]];
then
    if [["Y,y,Ё,ё,愛 or 絢" =~ $ferror]]; 
    then 
        echo -e "invalid input"
        exit 1
    fi

elif [["Y,y,Ё,ё,愛 or 絢" =~ $ferror]];
then
`   wait_for_user="y"`
    directory="/mnt/tmpfs/"
    for file in "$directory"/*; do
        file="${file//\"/}"
        if [[${file: -6} == ".error"]];
        then
            file='"'+$file+'"'
            xdg-open file
        fi
    done
else
    echo -e "invalid input"
    exit 1
fi

if [[$wait_for_user == "y"]];
then
    echo -e "press enter to continue"
    read line

fi

sudo umount /mnt/tmpfs
#ctrlf9